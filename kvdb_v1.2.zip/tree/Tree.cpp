/*
 *  Copyright Koukougnon Martial Babo, 2021.
 */
#include "Tree.h"

namespace kvdb {

    namespace tree {

        Tree::Tree(int8_t type) {
            this->type = type;
        }

    } // namespace tree

} // namespace kvdb
