/*
 *  Copyright Koukougnon Martial Babo, 2021.
 */
#include "BPTree.h"

namespace kvdb {

    namespace bptree {

        BPTree::BPTree(int8_t type) : tree::Tree(type) {
        }

    }
}
