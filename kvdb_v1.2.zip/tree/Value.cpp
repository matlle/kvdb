/*
 *  Copyright Koukougnon Martial Babo, 2021.
 */
#include "Value.h"

namespace kvdb {

    namespace btree {

        Value::Value() = default;

    } // namespace btree

} // namespace kvdb
